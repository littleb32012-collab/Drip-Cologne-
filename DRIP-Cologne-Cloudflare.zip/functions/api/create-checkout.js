const PRODUCTS = {
  "DRIP Ocean": { unit_amount: 1000 },
  "DRIP Midnight": { unit_amount: 1000 },
  "DRIP Vanilla": { unit_amount: 1000 },
  "Cherry Noir": { unit_amount: 1000 },
  "Arctic Rush": { unit_amount: 1000 },
  "Pumpkin Spice": { unit_amount: 1000 },
  "Maple Cinnamon": { unit_amount: 1000 },
  "Pink Rush": { unit_amount: 1000 },
  "Sweet Kiss": { unit_amount: 1000 },
  "Peach Glow": { unit_amount: 1000 },
  "Coco Dream": { unit_amount: 1000 },
  "Moonlight": { unit_amount: 1000 }
};

function json(data, status = 200) {
  return new Response(JSON.stringify(data), {
    status,
    headers: { "Content-Type": "application/json" }
  });
}

export async function onRequestPost(context) {
  const { request, env } = context;
  const secret = env.STRIPE_SECRET_KEY;

  if (!secret) {
    return json({
      error: "Stripe is not connected yet. Add STRIPE_SECRET_KEY in Cloudflare Pages settings."
    }, 500);
  }

  try {
    const body = await request.json();
    if (!Array.isArray(body.items) || !body.items.length) {
      throw new Error("Your cart is empty.");
    }

    const params = new URLSearchParams();
    params.set("mode", "payment");

    const origin = new URL(request.url).origin;
    params.set("success_url", origin + "/?success=1");
    params.set("cancel_url", origin + "/?canceled=1");
    params.set("billing_address_collection", "auto");
    params.set("phone_number_collection[enabled]", "true");
    params.set("shipping_address_collection[allowed_countries][0]", "US");

    body.items.forEach((item, i) => {
      const name = typeof item.name === "string" ? item.name : "";
      const qty = Number.isInteger(item.qty) ? item.qty : 0;
      const product = PRODUCTS[name];

      if (!product || qty < 1 || qty > 20) {
        throw new Error("Invalid product or quantity.");
      }

      params.set(`line_items[${i}][price_data][currency]`, "usd");
      params.set(`line_items[${i}][price_data][product_data][name]`, name);
      params.set(`line_items[${i}][price_data][product_data][description]`, "DRIP Cologne • 10 mL");
      params.set(`line_items[${i}][price_data][unit_amount]`, String(product.unit_amount));
      params.set(`line_items[${i}][quantity]`, String(qty));
    });

    const stripeResponse = await fetch("https://api.stripe.com/v1/checkout/sessions", {
      method: "POST",
      headers: {
        "Authorization": `Bearer ${secret}`,
        "Content-Type": "application/x-www-form-urlencoded"
      },
      body: params
    });

    const data = await stripeResponse.json();
    if (!stripeResponse.ok) {
      return json({
        error: data?.error?.message || "Stripe could not create checkout."
      }, 502);
    }

    return json({ url: data.url });
  } catch (error) {
    return json({ error: error.message || "Checkout request was invalid." }, 400);
  }
}

export async function onRequest(context) {
  if (context.request.method !== "POST") {
    return json({ error: "Method not allowed." }, 405);
  }
  return onRequestPost(context);
}
