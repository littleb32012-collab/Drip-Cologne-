DRIP Cologne — Cloudflare Pages + Stripe

This version has been converted from Netlify Functions to a Cloudflare Pages Function.

FILES
- index.html — storefront
- functions/api/create-checkout.js — Cloudflare checkout function
- wrangler.toml — Cloudflare Pages configuration

STRIPE SETUP
1. Create/activate your Stripe account.
2. Deploy this project to Cloudflare Pages.
3. In Cloudflare, open the Pages project and add an environment variable named:
   STRIPE_SECRET_KEY
4. Set its value to your Stripe Secret API key. Keep this key private and never put it in index.html.
5. Redeploy after adding/changing the variable.

DEPLOY WITH WRANGLER
From this folder:
  npx wrangler login
  npx wrangler pages deploy .

Or connect the folder through a GitHub repository to Cloudflare Pages. Cloudflare Pages will detect the functions/ directory.

CHECKOUT
The checkout endpoint is now:
  /api/create-checkout

All 12 DRIP fragrances are validated at $10 each:
DRIP Ocean, DRIP Midnight, DRIP Vanilla, Cherry Noir, Arctic Rush, Pumpkin Spice, Maple Cinnamon, Pink Rush, Sweet Kiss, Peach Glow, Coco Dream, Moonlight.

Shipping address collection is limited to the United States, and no shipping fee is added in this version.
